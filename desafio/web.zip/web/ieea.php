<?php
// Función para calcular el IEEA
function calcularIEEA($areaEdificio, $aislamientoTérmico) {
    if ($areaEdificio == 0 || $aislamientoTérmico == 0) {
        return 0;
    }
    return $areaEdificio / $aislamientoTérmico;
}

// Función para mostrar la categoría del IEEA
function mostrarCategoriaIEEA($ieaa) {
    $categoria = '';
    if ($ieaa < 100) {
        $categoria = 'Bajo';
    } elseif ($ieaa < 150) {
        $categoria = 'Medio';
    } elseif ($ieaa < 200) {
        $categoria = 'Alto';
    } else {
        $categoria = 'Muy Alto';
    }
    return "La categoría del IEEA es: " . $categoria;
}

// Función principal
function main() {
    // Verificar si hay suficientes argumentos
    if (!isset($_GET['areaEdificio']) && !isset($_GET['aislamientoTérmico'])) {
        echo "<form action='?' method='get'>";
        echo "Área del edificio (m²): <input type='text' name='areaEdificio'><br><br>";
        echo "Aislamiento térmico (W/m²K): <input type='text' name='aislamientoTérmico'><br><br>";
        echo "<input type='submit' value='Calcular IEEA'>";
        echo "</form>";
    } else {
        try {
            $areaEdificio = floatval(isset($_POST['areaEdificio']) ? $_POST['areaEdificio'] : $_GET['areaEdificio']);
            $aislamientoTérmico = floatval(isset($_POST['aislamientoTérmico']) ? $_POST['aislamientoTérmico'] : $_GET['aislamientoTérmico']);

            // Calcular el IEEA
            $ieaa = calcularIEEA($areaEdificio, $aislamientoTérmico);

            // Mostrar el resultado
            printf("El IEEA es: %.2f<br>", $ieaa);
            echo mostrarCategoriaIEEA($ieaa);

        } catch (Exception $e) {
            echo "Error: Los argumentos deben ser números válidos.<br>";
            echo "Por favor, vuelva a intentar.";
        }
    }

    // Si no se ingresaron valores por formulario o URL, mostrar cero
    if (!isset($_POST['areaEdificio']) && !isset($_GET['areaEdificio']) && !isset($_POST['aislamientoTérmico']) && !isset($_GET['aislamientoTérmico'])) {
        echo "<p>No se ingresaron valores. El resultado es cero.</p>";
    }
}

// Ejecutar la función principal
main();
?>
