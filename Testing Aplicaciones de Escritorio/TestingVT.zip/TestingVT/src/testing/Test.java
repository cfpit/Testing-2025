package testing;


public class Test {
    public static void main(String[] args) {
        System.out.println("Hola Mundo!!");
        
        int n1 = 10;
        int n2 = 20;
        
        n1 = 50;
        
        System.out.println("n2 = " + n2);
        
        boolean casado;
        casado = true;
        
        String mail = "juan123@gmail.com";
        System.out.println("mail = " + mail);
        
        System.out.println("operadores aritmeticos");
        int a = 10;
        int b = 5;
        
        System.out.println(a + b);//15
        
        System.out.println("operadores relacionales");
        System.out.println(a > b);//true
        System.out.println(a < b);//false
        System.out.println(a == b);//false
        System.out.println(a != b);//true
        
        System.out.println("operadores incrementales");
        int z = 1;
        System.out.println("z = " + z);//z = 1
        
        z ++;
        System.out.println("z = " + z);//z = 2
        
        z --;
        System.out.println("z = " + z);// z = 1
        
        z += 5;// z  = z + 5
        System.out.println("z = " + z);// z = 6
        
        z *= 4;// z = z * 4
        System.out.println("z = " + z);// z = 24
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
}
