package testing;

import java.util.Scanner;

public class Login {
    public static void main(String[] args) {
        Scanner lector = new Scanner(System.in);
        
        System.out.println("Decime tu nombre: ");
        String nombre = lector.next();
        
        if (nombre.equals("Juan")) {
            System.out.println("Bienvenido Juancito!!");
        } else {
            System.out.println("No te conozco");
        }
        
    }
}
